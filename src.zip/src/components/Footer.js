function Footer() {
    return (
        <footer className="bg-dark text-white text-center py-3">
            Copyright &copy; 2023
        </footer>
    )
}

export default Footer;